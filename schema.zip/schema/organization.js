//COMPANY SCHEMA
orgs = [
    {
        _id: '',
        companyID: '',
        email: '',
        name: '',
        areaOfWork: '',
        isVerified: '',
        isDeleted: '',
        profile: {
            about: '',
            locations: [],
            followers: [],
            post: [
                {
                    postId: '',
                    content: '',
                    timestamp:'',
                    likes: [
                        {
                            likedBy: '',
                            timestamp: ISODATE()
                        }
                    ],
                    comments: [
                        {
                            commentedBy: '',
                            content: '',
                            timestamp: ISODATE()
                        }
                    ]           
                }
            ],
            jobs: [
                {
                    jobId: '',
                    position: '',
                    timestamp: '',
                    lastDate: '',
                    applicants: []
                }
            ]
        }

    }
]

