//USER SCHEMA
users = [
    {
        _id: '',
        userName: '',
        name: '',
        email: '',
        mobile: '',
        gender: '',
        dateOfBirth: ISODATE(),
        isVerified: '',
        isDeleted: '',
        profile: {
            bio: '',
            image: 'imgUrl',
            experience: [
                {
                    designation: '',
                    companyName: '',
                    timePeriod: ''
                }
            ],
            education: [
                {
                    degreeName: '',
                    university: '',
                    percentage: '',
                    yearOfPassing:''
                }
            ],
            accomplishment: {
                certifications: [
                    {
                        name: '',
                        issuedBy: '',
                        year:'',
                    }
                ],
                awards: [
                    {
                        name: '',
                        awardedBy: '',
                        year:'',
                    }
                ],
                publications: [
                    {
                        name: '',
                        topic: '',
                        publishedBy:'',
                        year:''
                    }
                ]
            },
            skills: [],
            endorsements: [
                {
                    endorsedBy: '',
                    comment: ''
                }
            ]
        },
        posts: [
            {
                postId: '',
                content: '',
                //postImage: '(file)',
                timestamp: ISODATE(),
                likes: [
                    {
                        likedBy: '',
                        timestamp: ISODATE()
                    }
                ],
                comments: [
                    {
                        commentBy: '',
                        content: '',
                        timestamp: ISODATE()
                    }
                ]
            }
        ],
        blocklist: {
            blocked: [],
            blockedBy: [],
        },
        connectionRequests: {
            sent: [],
            receive: []
        },
        connections: [],
        followings: [],
        followingCompany: [],
        followers: [],
    }
    ]
