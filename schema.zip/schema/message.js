conversations: [{
    participants: [],
    messages: [
        {
            content: '',
            sender: '',
            timestamp: ''
        }
    ]
}
]